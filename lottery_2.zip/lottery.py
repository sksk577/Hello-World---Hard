import random
import tkinter as tk
from matgo import *
from tkinter import *
from tkinter import font
from daylotto import *
import time
class Main:
	def __init__(self, root):
		self.money=50000000
		self.announce=""
		self.date=1
		self.police_stars=0
		self.bank_debt=0
		self.private_debt=0
		self.root=root
		self.choosehorse=[]
		self.chooseimm=[]
		self.immlotto=[0,0,0,0,0]
		Label(self.root ,text = "").grid(row=1, column=0)
		Label(self.root ,text = "          ").grid(row=2, column=0)
		Label(self.root ,text = "             ").grid(row=0, column=2)
		Label(self.root ,text = "             ").grid(row=0, column=4)
		font = tk.font.Font(self.root, size=13)
		font2 = tk.font.Font(self.root, size=11)
		self.asset = Label(self.root,text = "현재 전재산 : "+str(self.money), relief="solid", padx=5, pady=5)
		self.asset['font']=font2
		self.asset.place(x=1, y=1)
		self.info = Label(self.root,text = "<                 상황판                 >\n"+self.announce)
		self.info.place(x=410, y=0)
		self.today = Label(self.root,text = "도박인생 "+str(self.date)+"일차", relief="solid", padx=5, pady=5)
		self.today['font']=font2
		self.today.place(x=230, y=0)
	def update(self):
		font = tk.font.Font(self.root, size=13)
		font2 = tk.font.Font(self.root, size=11)
		self.asset.destroy()
		self.asset = Label(self.root,text = "현재 전재산 : "+str(self.money), relief="solid", padx=5, pady=5)
		self.asset['font']=font2
		self.asset.place(x=1, y=1)
		self.info.destroy()
		self.info = Label(self.root,text = "<                 상황판                 >\n"+self.announce)
		self.info.place(x=410, y=0)
		self.today.destroy
		self.today = Label(self.root,text = "도박인생 "+str(self.date)+"일차", relief="solid", padx=5, pady=5)
		self.today['font']=font2
		self.today.place(x=230, y=0)
	def addannounce(self, string, root):
		if self.money<=0:
			gg=Toplevel(root)
			field_pic=PhotoImage(file="./images/gg.png")
			field=Label(gg, image=field_pic)
			field.place(x=0, y=0)
			gg.title("게임 오버")
			gg.geometry("280x186")
			font = tk.font.Font(self.root, size=12)
			msg = Label(gg, text="파산하셨습니다.\n오늘은 한강물이 차갑군요.")
			msg['font']=font
			msg.place(x=45, y=20)
			def quit():
				root.destroy()
				root.quit()
				self.root.destroy()
				self.root.quit()
			Button(gg,text = "확인", command = quit).place(x=120, y=150)			
			gg.mainloop()		
		else:
			self.announce=string
			if self.bank_debt>0:
				self.announce+="현재 대출빚이 "+str(self.bank_debt)+"원입니다.\n이자로 "+str(int(self.bank_debt*0.05))+"원이 빠져나갑니다.\n"
				self.money-=int(self.bank_debt*0.05)
			if self.private_debt>0:
				self.announce+="현재 사채빚이 "+str(self.private_debt)+"원입니다.\n이자로 "+str(int(self.private_debt*0.2))+"원이 빠져나갑니다.\n"
				self.money-=int(self.private_debt*0.2)
			return True
	def arrested(self):
		r=random.randrange(1000)
		if r<self.police_stars:
			arrestroot = Toplevel(self.root)
			field_pic=PhotoImage(file = "./images/arrest.png")
			field=Label(arrestroot, image=field_pic)
			field.place(x=0, y=0)
			arrestroot.title("체포되었습니다")
			arrestroot.geometry("320x202")
			font = tk.font.Font(self.root, size=12)
			msg = Label(arrestroot, text="경찰에 체포되셨습니다.\n인생을 돌아보십시오.")
			msg['font']=font
			msg.place(x=70, y=100)
			def quit():
				self.root.destroy()
				self.root.quit()
				return False
			Button(arrestroot,text = "확인", command = quit).place(x=137, y=150)
			arrestroot.mainloop()
		else:
			return True
	def mainscreen(self):
		def d_lotto():
			window=Toplevel(self.root)
			result = day_lotto_start(window)
			resultroot = Toplevel(self.root)
			resultroot.title("결과")
			resultroot.geometry("160x160")
			field_pic=PhotoImage(file = "./images/gold.png")
			field=Label(resultroot, image=field_pic).place(x=0, y=0)
			font2 = tk.font.Font(self.root, size=11)
			def quit():
				self.date+=1
				self.money-=1000000
				string="일일복권으로 "+str(result)+"원을 얻었습니다.\n복권가격으로 100만원을 사용했습니다."
				self.money+=result
				check = self.addannounce(string, resultroot)
				if check:
					self.update()
					resultroot.destroy()
					resultroot.quit()
			if int(result)>=0:
				get=Label(resultroot, text=str(result)+"원을\n따냈습니다.")
				get['font']=font2
				get.place(x=35, y=30)
			else:
				get=Label(resultroot, text=str(result*(-1))+"원을\n잃었습니다.")
				get['font']=font2
				get.place(x=35, y=30)
			font = tk.font.Font(self.root, size=13)
			quitbutton=Button(resultroot,text = "확인", command = quit)
			quitbutton['font']=font
			quitbutton.place(x=60, y=115)
			resultroot.mainloop()
		def i_lotto():
			self.chooseimm=[]
			self.immlotto=[0, 0, 0, 0, 0]
			while len(self.chooseimm)!=100:
				self.chooseimm.append(random.randrange(1, 8145061))
			for i in self.chooseimm:
				if 3821291<=i<3821311:
					self.immlotto[0]+=1
				elif 5182932<=i<5184281:
					self.immlotto[1]+=1
				elif 582<=i<9821:
					self.immlotto[2]+=1
				elif 688428<=i<984231:
					self.immlotto[3]+=1
				elif 1042912<=i<2042912:
					self.immlotto[4]+=1
			immroot = Toplevel(self.root)
			immroot.title("즉석복권")
			immroot.geometry("320x195")
			field_pic=PhotoImage(file = "./images/imm_lottery.png")
			field=Label(immroot, image=field_pic)
			field.place(x=0, y=0)
			font = tk.font.Font(root, size=13, weight='bold')
			font2 = tk.font.Font(root, size=11)
			msg=Label(immroot, text="즉석복권 100개를 사서 긁었습니다.")
			msg['font']=font
			msg.place(x=25, y=3)
			k=0
			if self.immlotto[0]>0:
				one=Label(immroot, text="1등이 "+str(self.immlotto[0])+"번 당첨되었습니다.")
				one['font']=font2
				one.place(x=70, y=40)
				k+=1
			if self.immlotto[1]>0:
				two=Label(immroot, text="2등이 "+str(self.immlotto[1])+"번 당첨되었습니다.")
				two['font']=font2
				two.place(x=70, y=40+23*k)
				k+=1
			if self.immlotto[2]>0:
				three=Label(immroot, text="3등이 "+str(self.immlotto[2])+"번 당첨되었습니다.")
				three['font']=font2
				three.place(x=70, y=40+23*k)
				k+=1
			if self.immlotto[3]>0:
				four=Label(immroot, text="4등이 "+str(self.immlotto[3])+"번 당첨되었습니다.")
				four['font']=font2
				four.place(x=70, y=40+23*k)
				k+=1
			if self.immlotto[4]>0:
				five=Label(immroot, text="5등이 "+str(self.immlotto[4])+"번 당첨되었습니다.")
				five['font']=font2
				five.place(x=70, y=40+23*k)
			def quit():
				self.date+=1
				self.money-=1000000
				addmoney=200000000*self.immlotto[0]+30000000*self.immlotto[1]+500000*self.immlotto[2]+50000*self.immlotto[3]+3000*self.immlotto[4]
				string="즉석복권에 100만원을 사용했습니다.\n"+"1등이 "+str(self.immlotto[0])+"번\n"+"2등이 "+str(self.immlotto[1])+"번\n"+"3등이 "+str(self.immlotto[2])+"번\n"
				string+="4등이 "+str(self.immlotto[3])+"번\n"+"5등이 "+str(self.immlotto[4])+"번\n당첨되었습니다.\n"+str(addmoney)+"원을 얻었습니다.\n"
				self.money+=addmoney
				check = self.addannounce(string, immroot)
				if check:
					self.update()
					immroot.destroy()
					immroot.quit()				
			quitbutton=Button(immroot,text = "확인", command = quit)
			quitbutton.place(x=147, y=160)
			immroot.mainloop()


		def l_lotto():
			self.root.quit()
		def matgo():
			result=matgostart(self.root, self.money)
			resultroot = Toplevel(self.root)
			resultroot.title("결과")
			resultroot.geometry("290x171")
			field_pic=PhotoImage(file = "./images/hwato.png")
			field=Label(resultroot, image=field_pic).place(x=0, y=0)
			def quit():
				self.date+=1
				self.money+=int(result)
				if int(result)>=0:
					check = self.addannounce(str(result)+"원을 맞고로 얻었습니다.\n", resultroot)
				else:
					check = self.addannounce(str(result*(-1))+"원을 맞고로 잃었습니다.\n", resultroot)
				if check:
					self.update()
					resultroot.destroy()
					resultroot.quit()
			if int(result)>=0:
				Label(resultroot, text=str(result)+"원을 얻었습니다.").place(x=80, y=100)
			else:
				Label(resultroot, text=str(result*(-1))+"원을 잃었습니다.").place(x=80, y=100)
			quitbutton=Button(resultroot,text = "확인", command = quit)
			quitbutton.place(x=130, y=130)
			resultroot.mainloop()
		def horse():
			self.choosehorse=[]
			horse=[1,2,3,4,5,6,7,8]
			winhorse=horse.pop(random.randrange(8))
			sechorse=horse.pop(random.randrange(7))
			horseloot = Toplevel(self.root)
			horseloot.title("경마")
			horseloot.geometry("400x234")
			field_pic=PhotoImage(file = "./images/horse.png")
			field=Label(horseloot, image=field_pic)
			field.place(x=0, y=0)
			font = tk.font.Font(root, size=15, weight='bold')
			msg=Label(horseloot, text="1등, 2등 할 말을 예상하세요")
			msg['font']=font
			msg.place(x=70, y=3)
			def quit():
				input1=score1.get()
				input2=score2.get()
				self.date+=1
				if input1.isdigit() and 0 <= int(input1) and int(input1) <= 3 and input2.isdigit() and 0 <= int(input2) and int(input2):
					if team1_score==int(input1) and team2_score==int(input2):
						addmoney=750000*random.randrange(3, 15)
						self.money+=addmoney
						string=team1 + " VS "+team2+"의 경기는 \n" + str(team1_score) + " 대 " + str(team2_score) +"으로 끝났습니다.\n"+str(addmoney)+"원을 따냈습니다.\n"
					else:
						self.money-=2000000
						string=team1 + " VS "+team2+"의 경기는 \n" + str(team1_score) + " 대 " + str(team2_score) +"으로 끝났습니다.\n2000000원을 잃었습니다.\n"
					check = self.addannounce(string, horseloot)
					if check:
						self.update()
						horseloot.destroy()
						horseloot.quit()
				else:
					input1=score1.get()
					input2=score2.get()
			def choose1():
				b1=Label(horseloot, text="★")
				b1.place(x=8, y=40)
				if 1 not in self.choosehorse:
					self.choosehorse.append(1)
				if len(self.choosehorse)==2:
					determine(self.choosehorse)
			def choose2():
				b2=Label(horseloot, text="★")
				b2.place(x=108, y=40)
				if 2 not in self.choosehorse:
					self.choosehorse.append(2)
				if len(self.choosehorse)==2:
					determine(self.choosehorse)
			def choose3():
				b3=Label(horseloot, text="★")
				b3.place(x=208, y=40)
				if 3 not in self.choosehorse:
					self.choosehorse.append(3)
				if len(self.choosehorse)==2:
					determine(self.choosehorse)
			def choose4():
				b4=Label(horseloot, text="★")
				b4.place(x=308, y=40)
				if 4 not in self.choosehorse:
					self.choosehorse.append(4)
				if len(self.choosehorse)==2:
					determine(self.choosehorse)
			def choose5():
				b5=Label(horseloot, text="★")
				b5.place(x=8, y=130)
				if 5 not in self.choosehorse:
					self.choosehorse.append(5)
				if len(self.choosehorse)==2:
					determine(self.choosehorse)
			def choose6():
				b6=Label(horseloot, text="★")
				b6.place(x=108, y=130)
				if 6 not in self.choosehorse:
					self.choosehorse.append(6)
				if len(self.choosehorse)==2:
					determine(self.choosehorse)
			def choose7():
				b7=Label(horseloot, text="★")
				b7.place(x=208, y=130)
				if 7 not in self.choosehorse:
					self.choosehorse.append(7)
				if len(self.choosehorse)==2:
					determine(self.choosehorse)
			def choose8():
				b8=Label(horseloot, text="★")
				b8.place(x=308, y=130)
				if 8 not in self.choosehorse:
					self.choosehorse.append(8)
				if len(self.choosehorse)==2:
					determine(self.choosehorse)
			def determine(choose):
				self.date+=1
				if choose[0]==winhorse and choose[1]==sechorse or choose[0]==sechorse and choose[1]==winhorse:
					addmoney=500000*random.randrange(10, 25)
					self.money+=addmoney
					string="1등은 "+str(winhorse)+"번 말\n 2등은 "+str(sechorse)+"번 말이 차지했습니다. \n"+str(addmoney)+"원을 따냈습니다."
					check = self.addannounce(string, horseloot)
					if check:
						self.update()
						horseloot.destroy()
						horseloot.quit()
				else:
					self.money-=1500000
					string="1등은 "+str(winhorse)+"번 말\n 2등은 "+str(sechorse)+"번 말이 차지했습니다. \n1500000원을 잃었습니다."
					check = self.addannounce(string, horseloot)
					if check:
						self.update()
						horseloot.destroy()
						horseloot.quit()				
				
			horse1=PhotoImage(file = "./images/horse1.png")
			horse2=PhotoImage(file = "./images/horse2.png")
			horse3=PhotoImage(file = "./images/horse3.png")
			horse4=PhotoImage(file = "./images/horse4.png")
			horse5=PhotoImage(file = "./images/horse5.png")
			horse6=PhotoImage(file = "./images/horse6.png")
			horse7=PhotoImage(file = "./images/horse7.png")
			horse8=PhotoImage(file = "./images/horse8.png")
			b1=Button(horseloot, image = horse1, command = choose1)
			b1.place(x=8, y=40)
			b2=Button(horseloot, image = horse2, command = choose2)
			b2.place(x=108, y=40)
			b3=Button(horseloot, image = horse3, command = choose3)
			b3.place(x=208, y=40)
			b4=Button(horseloot, image = horse4, command = choose4)
			b4.place(x=308, y=40)
			b5=Button(horseloot, image = horse5, command = choose5)
			b5.place(x=8, y=130)
			b6=Button(horseloot, image = horse6, command = choose6)
			b6.place(x=108, y=130)
			b7=Button(horseloot, image = horse7, command = choose7)
			b7.place(x=208, y=130)
			b8=Button(horseloot, image = horse8, command = choose8)
			b8.place(x=308, y=130)
			horseloot.mainloop()
		def stock():
			self.root.quit()
		def loan():
			loanroot = Toplevel(self.root)
			loanroot.title("ATM")
			loanroot.geometry("250x165")
			field_pic=PhotoImage(file = "./images/atm.png")
			field=Label(loanroot, image=field_pic).place(x=0, y=0)
			def quit():
				money=amount.get()
				if money.isdigit() and int(money)>=100000:
					if self.bank_debt>10000000:
						cannot = Toplevel(loanroot)
						cannot.title("대출 불가")
						Label(cannot, text = "현재 대출한 금액이 1000만원이 넘어 대출하실 수 없습니다.").pack()
						def quit():
							cannot.destroy()
							cannot.quit()
						quitbutton = Button(cannot,text = "확인", command = quit)
						quitbutton.pack()
						cannot.mainloop()
					else:
						self.date+=1
						self.money+=int(money)
						self.bank_debt+=int(money)
						check=self.addannounce(money+"원을 대출했습니다.\n", loanroot)
						if check:
							self.update()
							loanroot.destroy()
							loanroot.quit()
				else:
					money=amount.get()
			def quit2():
				money=amount2.get()
				if money.isdigit() and int(money)<=self.bank_debt:
					self.date+=1
					self.money-=int(money)
					self.bank_debt-=int(money)
					check=self.addannounce(money+"원을 갚았습니다.\n", loanroot)
					if check:
						self.update()
						loanroot.destroy()
						loanroot.quit()
				else:
					money=amount2.get()
			Label(loanroot, text="얼마를 갚으시겠습니까?").place(x=63, y=15)
			amount2=Entry(loanroot)
			amount2.place(x=60, y=35)
			Button(loanroot,text = "확인", command = quit2).place(x=115, y=55)
			Label(loanroot, text="얼마를 빌리시겠습니까? (최소 10만)").place(x=25, y=90)
			amount=Entry(loanroot)
			amount.place(x=60, y=110)
			Button(loanroot,text = "확인", command = quit).place(x=115, y=130)
			loanroot.mainloop()
		def bond():
			bondroot = Toplevel(self.root)
			bondroot.title("산와머니")
			bondroot.geometry("250x165")
			field_pic=PhotoImage(file = "./images/bond.png")
			field=Label(bondroot, image=field_pic).place(x=0, y=0)
			def quit():
				money=amount.get()
				if money.isdigit() and int(money)>=500000:
					self.date+=1
					self.money+=int(money)
					self.private_debt+=int(money)
					check = self.addannounce(money+"원을 대출했습니다.\n", bondroot)
					if check:
						self.update()
						bondroot.destroy()
						bondroot.quit()
				else:
					money=amount.get()
			def quit2():
				money=amount2.get()
				if money.isdigit() and int(money)<=self.private_debt:
					self.date+=1
					self.money-=int(money)
					self.private_debt-=int(money)
					check = self.addannounce(money+"원을 갚았습니다.\n", bondroot)
					if check:
						self.update()
						bondroot.destroy()
						bondroot.quit()
				else:
					money=amount2.get()
			Label(bondroot, text="얼마를 갚으시겠습니까?").place(x=63, y=15)
			amount2=Entry(bondroot)
			amount2.place(x=60, y=35)
			Button(bondroot,text = "확인", command = quit2).place(x=115, y=55)
			Label(bondroot, text="얼마를 빌리시겠습니까? (최소 50만)").place(x=25, y=90)
			amount=Entry(bondroot)
			amount.place(x=60, y=110)
			Button(bondroot,text = "확인", command = quit).place(x=115, y=130)
			bondroot.mainloop()
		def fraud():
			check=self.arrested()
			if check:
				fraudroot = Toplevel(self.root)
				fraudroot.title("사기치기")
				fraudroot.geometry("250x250")
				fraudtype=random.randrange(5)
				if fraudtype==1:
					message = "보이스피싱을 했습니다\n"
				elif fraudtype==2:
					message = "게임머니 사기를 쳤습니다\n"
				elif fraudtype==3:
					message = "중고나라 사기를 쳤습니다\n"
				elif fraudtype==4:
					message = "친구에게 사기를 쳤습니다\n"
				else:
					message = "다단계로 물건을 팔았습니다\n"
				fraudmoney = random.randrange(1, 301)*10000
				for i in range(0, 8):
					Label(fraudroot, text="            ").grid(row=i, column=0)
				field_pic=PhotoImage(file = "./images/fraud.png")
				field=Label(fraudroot, image=field_pic)
				field.place(x=0, y=0)
				result = Label(fraudroot, text=message+str(fraudmoney)+"원을 얻었습니다.")
				result.grid(row=8, column=1)
				def quit():
					self.date+=1
					self.money+=fraudmoney
					string="사기로 "+str(fraudmoney)+"원을 획득였습니다.\n경찰의 주시도가 높아졌습니다.\n"
					self.addannounce(string, fraudroot)
					ran=random.randrange(50, 200)
					self.police_stars+=ran
					self.update()
					fraudroot.destroy()
					fraudroot.quit()
				Button(fraudroot,text = "확인", command = quit).place(x=110, y=210)
				fraudroot.mainloop()
		def toto():
			teamlist = ["대한민국", "일본", "중국", "미국", "프랑스", "독일", "영국", "스페인", "아르헨티나", "브라질", "그리스", "러시아", "호주"]
			team1 = teamlist.pop(random.randrange(13))
			team2 = teamlist.pop(random.randrange(12))
			team1_score=random.randrange(4)
			team2_score=random.randrange(4)
			totoroot = Toplevel(self.root)
			totoroot.title("토토복권")
			totoroot.geometry("297x210")
			field_pic=PhotoImage(file = "./images/toto.png")
			field=Label(totoroot, image=field_pic)
			field.place(x=0, y=0)
			font = tk.font.Font(root, size=15, weight='bold')
			font2 = tk.font.Font(root, size=14, weight='bold')
			msg=Label(totoroot, text="스코어를 입력하세요(3점 이하)")
			msg['font']=font
			msg.place(x=10, y=40)
			team=Label(totoroot, text=team1+" VS "+team2)
			team['font']=font2
			team.place(x=78, y=90)
			score1=Entry(totoroot)
			score1.place(x=105, y=140, width=30)
			VS=Label(totoroot, text="VS")
			VS.place(x=140, y=140)
			score2=Entry(totoroot)
			score2.place(x=165, y=140, width=30)
			def quit():
				input1=score1.get()
				input2=score2.get()
				self.date+=1
				if input1.isdigit() and 0 <= int(input1) and int(input1) <= 3 and input2.isdigit() and 0 <= int(input2) and int(input2):
					if team1_score==int(input1) and team2_score==int(input2):
						addmoney=750000*random.randrange(3, 15)
						self.money+=addmoney
						string=team1 + " VS "+team2+"의 경기는 \n" + str(team1_score) + " 대 " + str(team2_score) +"으로 끝났습니다.\n"+str(addmoney)+"원을 따냈습니다."
					else:
						self.money-=2000000
						string=team1 + " VS "+team2+"의 경기는 \n" + str(team1_score) + " 대 " + str(team2_score) +"으로 끝났습니다.\n2000000원을 잃었습니다."
					check = self.addannounce(string, totoroot)
					if check:
						self.update()
						totoroot.destroy()
						totoroot.quit()
				else:
					input1=score1.get()
					input2=score2.get()	
			Button(totoroot,text = "확인", command = quit).place(x=133, y=170)
			totoroot.mainloop()
		font = tk.font.Font(self.root, size=13)
		font2 = tk.font.Font(self.root, size=11)
		for i in range(3, 10):
			if(i%2==1):
				Label(self.root ,text = "").grid(row=i, column=0)
		day_lottery = Button(self.root,text = "일일복권 하러가기", command = d_lotto)
		day_lottery['font']=font
		day_lottery.grid(row=2, column=1)
		imm_lottery = Button(self.root,text = "즉석복권 하러가기", command = i_lotto)
		imm_lottery['font']=font
		imm_lottery.grid(row=4, column=1)
		lot_lottery = Button(self.root,text = "로또복권 하러가기", command = l_lotto)
		lot_lottery['font']=font
		lot_lottery.grid(row=6, column=1)
		lot_lottery = Button(self.root,text = "맞고 치러가기", command = matgo)
		lot_lottery['font']=font
		lot_lottery.grid(row=8, column=1)
		lot_lottery = Button(self.root,text = "경마 하러가기", command = horse)
		lot_lottery['font']=font
		lot_lottery.grid(row=10, column=1)
		imm_lottery = Button(self.root,text = "주식 하러가기", command = stock)
		imm_lottery['font']=font
		imm_lottery.grid(row=2, column=3)
		imm_lottery = Button(self.root,text = "은행 찾아가기", command = loan)
		imm_lottery['font']=font
		imm_lottery.grid(row=4, column=3)
		Label(self.root,text = "하루이자 5%").grid(row=5, column=3)
		imm_lottery = Button(self.root,text = "사채 찾아가기", command = bond)
		imm_lottery['font']=font
		imm_lottery.grid(row=6, column=3)
		Label(self.root,text = "하루이자 20%").grid(row=7, column=3)
		imm_lottery = Button(self.root,text = "사기치기", command = fraud)
		imm_lottery['font']=font
		imm_lottery.grid(row=8, column=3)
		imm_lottery = Button(self.root,text = "토토복권 하러가기", command = toto)
		imm_lottery['font']=font
		imm_lottery.grid(row=10, column=3)
		self.root.mainloop()

def main(root):
	def play():
		for child in root.winfo_children():
			child.destroy()
		root.geometry("648x286")
		Main(root).mainscreen()
	def quit():
		root.destroy()
		root.quit()
	font = tk.font.Font(root, size=23, weight='bold')
	play = Button(root, text ="시작하기", command = play)
	play.place(x=250, y=150)
	play['font']=font 
	quit = Button(root, text ="종료", command = quit)
	quit.place(x=280, y=250)
	quit['font']=font
	root.mainloop()	
root = Tk()
root.title("주갤러 인생 시뮬레이터")
root.geometry("648x406")
img_field = PhotoImage(file = "./images/start.png")
Label(root, image = img_field).place(x = 0, y = 0)
root.update()
main(root)
root.mainloop()