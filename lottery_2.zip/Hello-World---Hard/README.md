# Hello World-Hard

## commited program list

1. lottery.c



## manual of commited program

*lottery.c*
```
This program is a lottery program in 'Final Fantasy XIV'.
This program is just prototype, and will be modifyed in Python.

1. Program will make 3*3 matrix, and will put natual number randomly(1~9). these numbers are not revealed. 
2. Program will open one space in matrix, and you can choose three space, which you want to know.
3. You should choose one row, or column.
4. Program will open all numbers, and sum three numbers you choosed.
5. You will get the amount that corresponds to the sum of the numbers.
```
